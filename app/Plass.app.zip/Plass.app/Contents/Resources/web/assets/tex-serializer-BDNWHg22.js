import{c as e,l as t,o as n}from"./settings-BEKBwB3F.js";var r={},i=new Set;function a(e){return e.replace(/\\/g,`\0`).replace(/([{}$&#%_])/g,`\\$1`).replace(/~/g,`\\textasciitilde{}`).replace(/\^/g,`\\textasciicircum{}`).replace(/\u0000/g,`\\textbackslash{}`).replace(/\u2014/g,`---`).replace(/\u2013/g,`--`).replace(/\u201C/g,"``").replace(/\u201D/g,`''`).replace(/\u2018/g,"`").replace(/\u2019/g,`'`).replace(/\u2026/g,`\\ldots{}`).replace(/\u00A0/g,`~`).replace(/\u2318/g,`\\textsf{Cmd-}`).replace(/\u2325/g,`\\textsf{Opt-}`).replace(/\u21E7/g,`\\textsf{Shift-}`).replace(/\u2303/g,`\\textsf{Ctrl-}`).replace(/\u22EF/g,`$\\cdots$`).replace(/\u00B7/g,`\\textperiodcentered{}`)}function o(e){let t=``;return e.forEach(e=>{if(e.isText&&e.text){let n=new Set(e.marks.map(e=>e.type.name)),r=a(e.text);n.has(`code`)&&(r=`\\texttt{${r}}`),n.has(`strong`)&&(r=`\\textbf{${r}}`),n.has(`em`)&&(r=`\\emph{${r}}`),n.has(`strike`)&&(r=`\\sout{${r}}`),t+=r}else if(e.type.name===`math_inline`)t+=`$${e.attrs.src}$`;else if(e.type.name===`eq_ref`){let n=e.attrs.label;t+=i.has(n)?a(`@${n}`):/^(fig|tab|sec):/.test(n)?`\\ref{${n}}`:`\\eqref{${n}}`}else e.type.name===`citation`?t+=`\\cite{${e.attrs.key}}`:e.type.name===`footnote`?t+=`\\footnote{${o(e)}}`:e.type.name===`hard_break`?t+=` \\\\
`:e.type.name===`image`&&(t+=`\\includegraphics{${c(e.attrs.src)}}`)}),t}var s=!1;function c(e){return e.startsWith(`data:`)?(s=!0,`embedded-image.png`):e}function l(e,t){let n=``;return e.forEach(e=>{n+=d(e,t)}),n}function u(e,t){let n=[];e.forEach(e=>{let t=[];e.forEach(e=>{t.push({node:e,colspan:e.attrs.colspan??1,rowspan:e.attrs.rowspan??1,header:e.type.name===`table_header`,align:e.attrs.align??null})}),n.push(t)});let r=Math.max(...n.map(e=>e.reduce((e,t)=>e+t.colspan,0))),i=n.map(()=>Array(r).fill(!1)),s=Array(r).fill(`l`);n.forEach((e,t)=>{let n=0;for(let a of e){for(;n<r&&i[t][n];)n++;a.align&&!a.header&&(s[n]=a.align===`right`?`r`:a.align===`center`?`c`:`l`);for(let e=1;e<a.rowspan;e++)for(let r=0;r<a.colspan;r++)i[t+e]&&(i[t+e][n+r]=!0);n+=a.colspan}});let c=e.attrs.params||``,l=new Map,u=new Map,d=e=>e===`none`?`none`:parseFloat(e??`0.05`)>=.07?`heavy`:`light`;for(let e of c.matchAll(/table\.hline\(\s*y\s*:\s*(\d+)(?:[^)]*?stroke\s*:\s*(none|[\d.]+em))?[^)]*\)/g))l.set(+e[1],d(e[2]));for(let e of c.matchAll(/table\.vline\(\s*x\s*:\s*(\d+)(?:[^)]*?stroke\s*:\s*(none|[\d.]+em))?[^)]*\)/g))u.set(+e[1],d(e[2]));let f=e=>e===`heavy`?`\\midrule[\\heavyrulewidth]`:`\\midrule`,p=new Map;for(let e of c.matchAll(/table\.hline\(\s*start\s*:\s*(\d+),\s*end\s*:\s*(\d+),\s*y\s*:\s*(\d+)(?:[^)]*?stroke\s*:\s*(none|[\d.]+em))?[^)]*\)/g)){let t=d(e[4]);if(t===`none`)continue;let n=+e[3],r=(t===`heavy`?`\\cmidrule[\\heavyrulewidth](lr)`:`\\cmidrule(lr)`)+`{${+e[1]+1}-${+e[2]}}`,i=p.get(n)??[];i.push(r),p.set(n,i)}let m=e=>{let t=p.get(e);return t?t.join(``)+`
`:``},h=e=>{let t=``;return e.node.forEach(e=>{t&&(t+=` `),t+=o(e)}),e.header&&(t=`\\textbf{${t}}`),e.rowspan>1&&(t=`\\multirow{${e.rowspan}}{*}{${t}}`),e.colspan>1&&(t=`\\multicolumn{${e.colspan}}{c}{${t}}`),t},g=``;n.forEach((e,t)=>{let n=l.get(t);t>0&&n&&n!==`none`&&(g+=f(n)+`
`),t>0&&(g+=m(t));let a=[],o=0,s=0;for(;o<r;){if(i[t][o]){a.push(``),o++;continue}let n=e[s++];if(!n)break;a.push(h(n)),o+=n.colspan}g+=a.join(` & `)+` \\\\
`,t===0&&e.some(e=>e.header)&&!l.has(1)&&(g+=`\\midrule
`)});let _=e.attrs.caption||``,v=e.attrs.label||``,y=(e,t)=>{let n=l.get(e);return n?n===`none`?``:f(n)+`
`:t+`
`},b=`\\begin{tabular}{${s.map((e,t)=>u.get(t)&&u.get(t)!==`none`?`|`+e:e).join(``)}${u.get(r)&&u.get(r)!==`none`?`|`:``}}\n`+y(0,`\\toprule`)+m(0)+g+m(n.length)+y(n.length,`\\bottomrule`)+`\\end{tabular}`;return _?`\\begin{table}[htbp]\n\\centering\n\\caption{${a(_)}}\n`+(v?`\\label{${v}}\n`:``)+`${b}\n\\end{table}\n\n`:`\\begin{center}\n${b}\n\\end{center}\n\n`}function d(e,t){switch(e.type.name){case`paragraph`:{let t=o(e);return t.trim()?t+`

`:`~\\par

`}case`heading`:{let n=[`\\section`,`\\subsection`,`\\subsubsection`,`\\paragraph`,`\\subparagraph`,`\\subparagraph`][Math.min(6,e.attrs.level)-1],r=t.numberSections?``:`*`,i=e.attrs.label?`\\label{${e.attrs.label}}`:``;return`${n}${r}{${o(e)}}${i}\n\n`}case`math_display`:{let n=e.attrs.label?`\\label{${e.attrs.label}}`:``,r=e.attrs.src,i=e.attrs.numbered??(t.numberEquations||!!e.attrs.label),a=r.split(`
`).map(e=>e.trim()).filter(Boolean),o=(a.length>1||/(?<!\\)&/.test(r))&&!r.includes(`\\begin{`)?`\\begin{aligned}\n${a.join(` \\\\
`)}\n\\end{aligned}`:r;return i?`\\begin{equation}${n}\n${o}\n\\end{equation}\n\n`:`\\[\n${o}\n\\]\n\n`}case`figure`:{let t=e.attrs.label?`\\label{${e.attrs.label}}\n`:``,n=o(e);return`\\begin{figure}[htbp]\n\\centering\n\\includegraphics[width=0.8\\linewidth]{${c(e.attrs.src)}}\n`+(n?`\\caption{${n}}\n`:``)+t+`\\end{figure}

`}case`bullet_list`:case`ordered_list`:{let n=e.type.name===`bullet_list`?`itemize`:`enumerate`,r=`\\begin{${n}}\n`;return e.forEach(e=>{r+=`\\item `+l(e,t).trim()+`
`}),r+`\\end{${n}}\n\n`}case`blockquote`:return`\\begin{quote}\n${l(e,t).trim()}\n\\end{quote}\n\n`;case`grid`:{let n=e.attrs.columns,r=n.reduce((e,t)=>e+t,0),i=e=>(1-.03*(n.length-1))*e/r,a=``;return e.forEach(e=>{let r=[];e.forEach((e,a,o)=>{r.push(`\\begin{minipage}[t]{${i(n[o]??1).toFixed(3)}\\linewidth}\n${l(e,t).trim()}\n\\end{minipage}`)}),a+=`\\noindent
`+r.join(`\\hfill
`)+`

`}),a}case`code_block`:{let t=e.attrs.params;if(t===`typst-raw`||t===`md-raw`){let n=e.textContent.split(`
`).map(e=>`% `+e);return`% [Plass] ${t===`typst-raw`?`raw Typst`:`raw Markdown`} block with no LaTeX equivalent:\n${n.join(`
`)}\n\n`}return`\\begin{verbatim}\n${e.textContent}\n\\end{verbatim}\n\n`}case`table`:return u(e,t);case`bibliography`:return`\\bibliographystyle{unsrt}
\\bibliography{refs}

`;case`editor_comment`:return``;case`page_break`:return`\\clearpage

`;case`numbering_restart`:return`\\clearpage
\\pagenumbering{arabic}

`;case`horizontal_rule`:return`\\noindent\\hrulefill

`;case`image`:return`\\begin{center}\\includegraphics[width=0.8\\linewidth]{${c(e.attrs.src)}}\\end{center}\n\n`;default:return``}}function f(a){let c=n(a.attrs?.settings);r=t(c.mathMacros),s=!1;let u=c.sizePt<=10.5?10:c.sizePt<=11.5?11:12,f={letter:`letterpaper`,a4:`a4paper`,legal:`legalpaper`,b5:`b5paper`,a5:`a5paper`},p=e(c),m=f[c.page]??`paperwidth=${p.w}in,paperheight=${p.h}in`,h=``,g=``,_=``,v=null,y=!1,b=!1,x=!1;a.forEach(e=>{e.type.name===`doc_title`?h=o(e):e.type.name===`doc_authors`?g=o(e):e.type.name===`doc_date`?_=o(e):e.type.name===`abstract`?v=e:e.type.name===`numbering_restart`&&(y=!0)}),a.descendants(e=>((e.type.name===`table_cell`||e.type.name===`table_header`)&&(e.attrs.rowspan??1)>1&&(b=!0),e.isText&&e.marks.some(e=>e.type.name===`strike`)&&(x=!0),!0)),i=new Set,a.descendants(e=>(e.type.name===`math_display`&&e.attrs.label&&e.attrs.numbered===!1&&i.add(e.attrs.label),!0));let S=a.attrs?.bib,C=`% Exported from Plass (semantic export: content and structure,
`;C+=`% not layout — your journal template does the formatting).
`,S?.content&&(C+=`\\begin{filecontents*}[overwrite]{refs.bib}\n${S.content.trim()}\n\\end{filecontents*}\n\n`),C+=`\\documentclass[${u}pt,${m}]{article}\n`,C+=`\\usepackage[utf8]{inputenc}
\\usepackage[T1]{fontenc}
`,C+=`\\usepackage{amsmath,amssymb}
\\usepackage{graphicx}
\\usepackage{booktabs}
`,b&&(C+=`\\usepackage{multirow}
`),x&&(C+=`\\usepackage[normalem]{ulem}
`),c.parIndent||(C+=`\\usepackage{parskip}
`),C+=`\\usepackage[${m},top=${c.marginTop}in,right=${c.marginRight}in,bottom=${c.marginBottom}in,left=${c.marginLeft}in]{geometry}\n`;for(let[e,t]of Object.entries(r))C+=`\\newcommand{\\${e}}{${t}}\n`;return C+=`
`,h&&(C+=`\\title{${h}}\n`),g&&(C+=`\\author{${g}}\n`),C+=_?`\\date{${_}}\n`:h?`\\date{}
`:``,C+=`\\begin{document}

`,y&&(C+=`\\pagenumbering{roman}
`),h&&(C+=`\\maketitle

`),v&&(C+=`\\begin{abstract}\n${l(v,c).trim()}\n\\end{abstract}\n\n`),a.forEach(e=>{[`doc_title`,`doc_authors`,`doc_date`,`abstract`].includes(e.type.name)||(C+=d(e,c))}),C+=`\\end{document}
`,s&&(C=`% NOTE: this document contains pasted (embedded) images. Save the
% paper as a project folder in Plass so figures become real files,
% then re-export; embedded-image.png below is a placeholder name.
`+C),C}export{f as docToTex};